SET JOBS PREMIUM WEBSITE

Files:
- index.html
- style.css
- script.js

HOW TO USE
1. Open index.html in a browser to preview the website.
2. Before publishing, open script.js and change:
   SUBMISSION_EMAIL="contact@setjobs.com"
   to the real SET Jobs email.
3. Replace the phone placeholder in index.html.
4. If you have a real logo, photos, job listings, and social links, add them before publishing.

FORMS
The Find a Job and Hire Talent forms open the visitor's email application using mailto. For a production website, connect them to a form backend or your business email service.

CONTENT NOTE
The company facts and service descriptions are based on the supplied SET Jobs document. No real job vacancies were invented because the source did not provide current openings.
